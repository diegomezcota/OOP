#include <iostream>
#include <string>

using namespace std;

#include <actor.h>
#include <function.h>
#include <movie.h>

int main() {
  std::cout << "Hello World!\n";
}