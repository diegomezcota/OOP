#include <iostream>
#include <string>

using namespace std;

#include <actor.h>
#include <function.h>
#include <movie.h>

int main() {
  movie mMovie;
  hour hHour;
  function fFunction;
  actor aActor;
}