#include <iostream>

#include <triangleName.h>

using namespace std;

//A00824758
//Diego Gomez Cota

int main() {
  
  triangleName t(6, '$', "Diego Gomez Cota");
  t.show();

  return 0;
}